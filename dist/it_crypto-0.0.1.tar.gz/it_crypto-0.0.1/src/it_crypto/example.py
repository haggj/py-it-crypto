class ItCrypto:
    @staticmethod
    def test():
        print("Hir from ITCypto")

def add_one(number):
    return number + 1